import pandas as pd
import numpy as np
import io
import re

def clean_gcf(text):
    """
    Extracts a standardized biological accession identifier from a raw string.

    The function searches for common genomic accession patterns such as 
    GCF, GCA, NC, or NZ followed by a numeric identifier and version 
    (e.g., GCF_000001405.39). If such a pattern is detected, the matched 
    identifier is returned.

    If no accession pattern is found, the function falls back to returning 
    the first two underscore-separated segments of the input string. This 
    provides a simplified identifier that can still be used for grouping 
    or indexing genomic records.

    Args:
        text (str): Raw identifier string that may contain additional 
        suffixes or descriptors (e.g., "NC_000913.3_prot_123").

    Returns:
        cleaned_id (str): Standardized identifier extracted from the input string.
    """
    pattern = r'([A-Z]{2,3}_\d+\.\d+)'
    match = re.search(pattern, str(text))
    
    if match:
        return match.group(1)

    return '_'.join(str(text).split('_')[:2])

def create_universal_matrix(data_file, tax_file):
    """
    Creates a binary presence/absence matrix linking genomes to functional annotations.

    The function loads functional annotation data and taxonomic metadata, 
    standardizes genome identifiers, and filters the dataset to include only 
    valid records present in both inputs. It then constructs a binary matrix 
    where rows represent genomes and columns represent unique functional 
    annotations. A value of 1 indicates the presence of a given annotation 
    in a genome, while 0 indicates absence.

    The resulting matrix can be used for downstream analyses such as clustering, 
    dimensionality reduction, or comparative genomic studies.

    Args:
        data_file (str or file-like object): Tab-separated file containing genome 
        identifiers and their functional annotations.
        tax_file (str or file-like object): Tab-separated file containing taxonomic 
        metadata with genome identifiers.

    Returns:
        matrix_bin (pd.DataFrame): Binary presence/absence matrix (rows: genomes, 
        columns: functional annotations).
        metadata_df (pd.DataFrame): Metadata aligned with the rows of matrix_bin.
    """
    tax_df = pd.read_csv(tax_file, sep='\t', dtype=str)
    
    if 'ID' not in tax_df.columns:
        tax_df.rename(columns={tax_df.columns[0]: 'ID'}, inplace=True)
    
    tax_df = tax_df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
    
    tax_df['ID_clean'] = tax_df['ID'].apply(clean_gcf)
    
    tax_df = tax_df.dropna(subset=['ID_clean', tax_df.columns[1]])
    
    valid_ids = set(tax_df['ID_clean'].unique())

    df = pd.read_csv(data_file, sep='\t', dtype=str)
    
    df.columns = [c.strip() for c in df.columns]
    
    if 'ID' not in df.columns or 'Functional Annotation' not in df.columns:
        df.columns = ['ID', 'Functional Annotation'] + list(df.columns[2:])

    df = df[df['Functional Annotation'].notna()]
    df = df[~df['Functional Annotation'].isin(['-', '', ' ', 'none', 'NaN'])]
    
    df['ID_clean'] = df['ID'].apply(clean_gcf)
    
    df = df[df['ID_clean'].isin(valid_ids)]
    
    if df.empty:
        return pd.DataFrame(), pd.DataFrame()

    unique_ids = df['ID_clean'].unique()
    unique_features = df['Functional Annotation'].unique()
    
    id_map = {name: i for i, name in enumerate(unique_ids)}
    feat_map = {name: i for i, name in enumerate(unique_features)}

    matrix = np.zeros((len(unique_ids), len(unique_features)), dtype=np.uint8)
    
    row_indices = df['ID_clean'].map(id_map).values.astype(int)
    col_indices = df['Functional Annotation'].map(feat_map).values.astype(int)
    matrix[row_indices, col_indices] = 1
    
    matrix_bin = pd.DataFrame(matrix, index=unique_ids, columns=unique_features)
    matrix_bin.columns = matrix_bin.columns.astype(str)

    metadata_df = tax_df.set_index('ID_clean').reindex(matrix_bin.index)
    
    return matrix_bin, metadata_df