import pandas as pd
import numpy as np
import plotly.express as px
from scipy.spatial.distance import pdist, squareform
from scipy.stats import fisher_exact
from statsmodels.stats.multitest import multipletests
from skbio.stats.distance import permanova
from skbio.stats.ordination import rda, pcoa, cca
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans
from sklearn.metrics import homogeneity_score, completeness_score, v_measure_score
from skbio import DistanceMatrix

def run_pca_plotly(matrix_bin, metadata_df, grouping_column):
    """
    Performs Principal Component Analysis (PCA) and generates an interactive scatter plot.
    
    The function standardizes the input binary matrix, reduces dimensionality to 
    the first two principal components, and merges the results with metadata 
    for visualization.

    Args:
        matrix_bin (pd.DataFrame): Binary presence/absence matrix (rows: genomes, columns: features).
        metadata_df (pd.DataFrame): Metadata containing taxonomic or environmental information.
        grouping_column (str): The column name in metadata_df used for color-coding the plot.

    Returns:
        fig (plotly.graph_objects.Figure): Interactive Plotly scatter plot of the PCA results.
        df_plot (pd.DataFrame): DataFrame containing PC coordinates, metadata, and genome IDs.
    """
    X_scaled = StandardScaler().fit_transform(matrix_bin)
    
    pca = PCA(n_components=2)
    components = pca.fit_transform(X_scaled)
    
    df_plot = pd.DataFrame(data=components, columns=['PC1', 'PC2'], index=matrix_bin.index)
    
    df_plot = df_plot.merge(metadata_df, left_index=True, right_index=True)
    df_plot['ID'] = df_plot.index
    
    fig = px.scatter(
        df_plot, x='PC1', y='PC2', color=grouping_column,
        hover_data=['ID'],
        title="PCA Analysis"
    )
    return fig, df_plot

def run_pcoa_plotly(matrix_bin, metadata_df, grouping_column, metric='jaccard'):
    """
    Performs Principal Coordinates Analysis (PCoA) and generates an interactive scatter plot.
    
    PCoA (also known as Multidimensional Scaling) is used to explore functional 
    dissimilarities between genomes based on non-Euclidean metrics. This is 
    particularly effective for binary microbial data as it properly handles 
    the "double zero" problem by focusing on shared presence rather than absence.

    Args:
        matrix_bin (pd.DataFrame): Binary presence/absence matrix (rows: genomes, columns: features).
        metadata_df (pd.DataFrame): Aligned metadata containing taxonomy or other grouping factors.
        grouping_column (str): The column in metadata_df used for color-coding the plot.
        metric (str, optional): The distance metric to use ('jaccard' or 'dice'). 
                                Defaults to 'jaccard'.

    Returns:
        fig (plotly.graph_objects.Figure): Interactive Plotly scatter plot with 
                                           explained variance on the axes.
        df_plot (pd.DataFrame): DataFrame containing the first two PCoA coordinates, 
                                metadata, and genome IDs.
    """
    data_float = matrix_bin.values.astype(float)
    dist_vec = pdist(data_float, metric=metric)
    dist_matrix = squareform(dist_vec)
    
    dm = DistanceMatrix(dist_matrix, ids=matrix_bin.index)
    pcoa_results = pcoa(dm)
    
    pcoa_df = pcoa_results.samples.iloc[:, 0:2]
    pcoa_df.columns = ['Axis 1', 'Axis 2']
    
    var_exp = pcoa_results.proportion_explained * 100
    
    df_plot = pcoa_df.merge(metadata_df, left_index=True, right_index=True)
    df_plot['ID'] = df_plot.index
    
    fig = px.scatter(
        df_plot, 
        x='Axis 1', 
        y='Axis 2', 
        color=grouping_column,
        hover_data=['ID'],
        title=f"PCoA Analysis (Metric: {metric.capitalize()})",
        labels={
            'Axis 1': f"PCoA 1 ({var_exp[0]:.1f}%)",
            'Axis 2': f"PCoA 2 ({var_exp[1]:.1f}%)"
        },
        template="plotly_white"
    )
    
    return fig, df_plot

def run_cca_plotly(matrix_bin, metadata_df, grouping_column):
    """
    Performs Canonical Correspondence Analysis (CCA) and generates an interactive scatter plot.
    
    CCA is a constrained ordination method that explores the relationship between 
    multivariate functional data (enzyme presence/absence) and external 
    explanatory variables (taxonomic groups). It identifies the variation in 
    functional profiles that can be strictly explained by the chosen metadata factor.

    The method utilizes Chi-square distances, making it suitable for frequency-like 
    data and sensitive to rare features that may characterize specific groups.

    Args:
        matrix_bin (pd.DataFrame): Binary presence/absence matrix (rows: genomes, columns: features).
        metadata_df (pd.DataFrame): Metadata containing the constraints (taxonomic levels).
        grouping_column (str): The column in metadata_df used as the constraint 
                               and for color-coding the plot.

    Returns:
        fig (plotly.graph_objects.Figure): Interactive Plotly scatter plot showing 
                                           the constrained ordination axes.
        df_plot (pd.DataFrame): DataFrame containing the CCA coordinates (site scores), 
                                metadata, and genome IDs.
    """
    Y = matrix_bin.astype(float)
    X = pd.get_dummies(metadata_df[grouping_column], prefix=grouping_column, dtype=float)

    cca_results = cca(Y, X)

    var_exp = cca_results.proportion_explained * 100
    
    genom_scores = cca_results.samples.iloc[:, 0:2]
    genom_scores.columns = ['CCA1', 'CCA2']
    
    df_plot = genom_scores.merge(metadata_df, left_index=True, right_index=True)
    df_plot['ID'] = df_plot.index
    
    fig = px.scatter(
        df_plot, 
        x='CCA1', 
        y='CCA2', 
        color=grouping_column,
        hover_data=['ID'],
        title="CCA Analysis",
        labels={
            'CCA1': f"CCA 1 ({var_exp[0]:.1f}%)",
            'CCA2': f"CCA 2 ({var_exp[1]:.1f}%)"
        },
        template="plotly_white"
    )

    return fig, df_plot

def run_cap_plotly(matrix_bin, metadata_df, grouping_column, metric='jaccard'):
    """
    Performs Canonical Analysis of Principal Coordinates (CAP) and generates an interactive scatter plot.
    
    CAP is a constrained ordination method (also known as Distance-based Redundancy Analysis, db-RDA). 
    It allows the use of non-Euclidean distance metrics (like Jaccard or Dice) while 
    constraining the ordination axes to specific explanatory variables (taxonomy).
    
    The process involves:
    1. Calculating a distance matrix using the selected metric.
    2. Performing Principal Coordinates Analysis (PCoA) on the distance matrix.
    3. Applying Redundancy Analysis (RDA) to the PCoA scores, constrained by metadata.

    Args:
        matrix_bin (pd.DataFrame): Binary presence/absence matrix (rows: genomes, columns: features).
        metadata_df (pd.DataFrame): Metadata containing the constraints (taxonomic levels).
        grouping_column (str): The column in metadata_df used as the constraint 
                               and for color-coding the plot.
        metric (str, optional): The distance metric to use ('jaccard' or 'dice'). 
                                Defaults to 'jaccard'.

    Returns:
        fig (plotly.graph_objects.Figure): Interactive Plotly scatter plot of the CAP results.
        df_plot (pd.DataFrame): DataFrame containing CAP coordinates, metadata, and genome IDs.
    """
    data_float = matrix_bin.values.astype(float)
    dist_vec = pdist(data_float, metric=metric)
    dist_matrix = squareform(dist_vec)
    
    dm = DistanceMatrix(dist_matrix, ids=matrix_bin.index)
    pcoa_results = pcoa(dm)

    Y_pcoa_scores = pcoa_results.samples

    X = pd.get_dummies(metadata_df[grouping_column], prefix=grouping_column, dtype=float)

    cap_results = rda(Y_pcoa_scores, X)

    var_exp = cap_results.proportion_explained * 100
    
    genom_scores = cap_results.samples.iloc[:, 0:2]
    genom_scores.columns = ['CAP1', 'CAP2']
    
    df_plot = genom_scores.merge(metadata_df, left_index=True, right_index=True)
    df_plot['ID'] = df_plot.index

    fig = px.scatter(
        df_plot, 
        x='CAP1', 
        y='CAP2', 
        color=grouping_column,
        hover_data=['ID'],
        title=f"CAP Analysis (Metric: {metric.capitalize()})",
        labels={
            'CAP1': f"CAP 1 ({var_exp[0]:.1f}%)",
            'CAP2': f"CAP 2 ({var_exp[1]:.1f}%)"
        },
        template="plotly_white"
    )
    
    fig.update_traces(marker=dict(size=8))
    fig.update_layout(
        xaxis=dict(zeroline=True, zerolinecolor='gray', zerolinewidth=1),
        yaxis=dict(zeroline=True, zerolinecolor='gray', zerolinewidth=1)
    )
    
    return fig, df_plot

def run_tsne_plotly(matrix_bin, metadata_df, grouping_column, perplexity=30, n_iter=1000):
    """
    Performs t-distributed Stochastic Neighbor Embedding (t-SNE) and generates an interactive plot.
    
    t-SNE is a non-linear dimensionality reduction technique specifically designed 
    to visualize high-dimensional datasets by preserving local structures. It is 
    excellent at revealing clusters and sub-groups within complex functional data 
    that might be obscured in global linear projections like PCA.

    The process includes:
    1. Standardizing the binary input matrix (critical for t-SNE performance).
    2. Initializing with PCA to improve global structure preservation.
    3. Iteratively optimizing the low-dimensional embedding.

    Args:
        matrix_bin (pd.DataFrame): Binary presence/absence matrix (rows: genomes, columns: features).
        metadata_df (pd.DataFrame): Metadata for color-coding and hover information.
        grouping_column (str): The column in metadata_df used for color-coding.
        perplexity (int, optional): The perplexity parameter related to the number 
                                    of nearest neighbors. Defaults to 30.
        n_iter (int, optional): Maximum number of iterations for the optimization. 
                                Defaults to 1000.

    Returns:
        fig (plotly.graph_objects.Figure): Interactive Plotly scatter plot.
        df_plot (pd.DataFrame): DataFrame containing the two t-SNE dimensions, 
                                metadata, and genome IDs.
    """
    data_scaled = StandardScaler().fit_transform(matrix_bin.astype(float))

    tsne = TSNE(
        n_components=2, 
        perplexity=perplexity, 
        max_iter=n_iter, 
        random_state=42,
        init='pca', 
        learning_rate='auto'
    )
    
    tsne_results = tsne.fit_transform(data_scaled)
    
    df_plot = pd.DataFrame(
        tsne_results, 
        columns=['t-SNE 1', 't-SNE 2'], 
        index=matrix_bin.index
    )
    df_plot = df_plot.merge(metadata_df, left_index=True, right_index=True)
    df_plot['ID'] = df_plot.index
    
    fig = px.scatter(
        df_plot, 
        x='t-SNE 1', 
        y='t-SNE 2', 
        color=grouping_column,
        hover_data=['ID'],
        title=f"t-SNE Analysis (Perplexity: {perplexity})",
        template="plotly_white"
    )
    
    fig.update_traces(marker=dict(size=8))
    
    return fig, df_plot

# def run_clustering_logic(df_ord, x_axis, y_axis, n_clusters=5):
#     """
#     Performs K-means clustering on ordination coordinates and generates a visualization.
    
#     This function applies the K-means algorithm to partition genomes into 'k' 
#     distinct clusters based on their positions in the 2D ordination space (e.g., 
#     PCA, PCoA, or t-SNE axes). It helps identify mathematically defined functional 
#     groups regardless of their taxonomic labels.

#     The process includes:
#     1. Extracting the selected ordination axes as input features.
#     2. Fitting the K-means model to identify cluster centroids.
#     3. Assigning each genome to the nearest cluster.
#     4. Generating an interactive Plotly scatter plot colored by cluster assignment.

#     Args:
#         df_ord (pd.DataFrame): DataFrame containing ordination coordinates and metadata.
#         x_axis (str): Column name for the X-axis (e.g., 'PC1' or 'Axis 1').
#         y_axis (str): Column name for the Y-axis (e.g., 'PC2' or 'Axis 2').
#         n_clusters (int, optional): The number of clusters (k) to form. Defaults to 5.

#     Returns:
#         fig (plotly.graph_objects.Figure): Interactive scatter plot with genomes 
#                                            colored by their assigned cluster.
#         df_copy (pd.DataFrame): A copy of the input DataFrame with an additional 
#                                 'Cluster' column containing the results.
#     """
#     df_copy = df_ord.copy()
    
#     X = df_copy[[x_axis, y_axis]].values
    
#     kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init='auto')
    
#     df_copy['Cluster'] = kmeans.fit_predict(X)
#     df_copy = df_copy.sort_values('Cluster')
#     df_copy['Cluster'] = df_copy['Cluster'].astype(str)
    
#     fig = px.scatter(
#         df_copy,
#         x=x_axis,
#         y=y_axis,
#         color='Cluster',
#         hover_data=['ID'],
#         title=f"K-means Clustering (k={n_clusters}) on {x_axis}/{y_axis}",
#         template="plotly_white",
#         color_discrete_sequence=px.colors.qualitative.Set2
#     )
#     fig.update_traces(marker=dict(size=8))
    
#     return fig, df_copy

def run_clustering_logic(df_ord, x_axis, y_axis, tax_col='Genus', n_clusters=5):
    df_copy = df_ord.dropna(subset=[x_axis, y_axis]).copy()
    
    # K-means clustering
    X = df_copy[[x_axis, y_axis]].values
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init='auto')
    df_copy['Cluster_Int'] = kmeans.fit_predict(X)
    
    # Seřazení pro legendu a vizualizaci
    df_copy = df_copy.sort_values('Cluster_Int')
    df_copy['Cluster'] = df_copy['Cluster_Int'].astype(str)
    
    # Vytvoření grafu s hover_data
    fig = px.scatter(
        df_copy,
        x=x_axis,
        y=y_axis,
        color='Cluster',
        # TADY přidáváme sloupce, které se zobrazí po najetí myší
        hover_data={'ID': True, tax_col: True, 'Cluster': True}, 
        title=f"K-means Clustering (k={n_clusters})",
        template="plotly_white",
        color_discrete_sequence=px.colors.qualitative.Set2,
        category_orders={"Cluster": [str(i) for i in sorted(df_copy['Cluster_Int'].unique())]}
    )
    fig.update_traces(marker=dict(size=9, line=dict(width=1, color='DarkSlateGrey')))
    
    return fig, df_copy

def get_clustering_metrics(df_clustered, true_label_col, cluster_col='Cluster'):
    """
    Evaluates the agreement between assigned clusters and ground-truth taxonomy.
    
    This function calculates several external validation metrics to assess how well 
    the mathematical clustering (based on functional data) reflects the 
    biological classification. It provides a quantitative measure of functional 
    conservation within taxonomic groups.

    Metrics calculated:
    - Purity: The average proportion of the majority taxonomic group in each cluster.
    - Homogeneity: High if each cluster contains only members of a single taxon.
    - Completeness: High if all members of a given taxon are assigned to the same cluster.
    - V-measure: The harmonic mean of Homogeneity and Completeness.

    Args:
        df_clustered (pd.DataFrame): DataFrame containing both assigned clusters 
                                     and true taxonomic labels.
        true_label_col (str): Name of the column containing ground-truth taxonomy 
                              (e.g., 'Genus', 'Order').
        cluster_col (str, optional): Name of the column containing cluster 
                                     assignments. Defaults to 'Cluster'.

    Returns:
        dict: A dictionary containing scores for Homogeneity, Completeness, 
              V-measure, and Purity (values range from 0.0 to 1.0).
    """
    df_clean = df_clustered.dropna(subset=[true_label_col, cluster_col])
    
    labels_true = df_clustered[true_label_col]
    labels_pred = df_clustered[cluster_col]
    
    results = {
        'Homogeneity': homogeneity_score(labels_true, labels_pred),
        'Completeness': completeness_score(labels_true, labels_pred),
        'V-measure': v_measure_score(labels_true, labels_pred),
    }
    
    contingency_matrix = pd.crosstab(labels_pred, labels_true)
    purity = contingency_matrix.max(axis=1).sum() / len(labels_true)
    results['Purity'] = purity
    
    return results

def run_enrichment_logic(matrix_bin, metadata_df, grouping_column, target_group, alpha=0.05):
    """
    Performs functional enrichment analysis to identify features overrepresented 
    in a target group.
    
    This function uses Fisher's Exact Test (one-sided, 'greater') to compare the 
    frequency of each feature (e.g., KOs, enzymes) in the target group against 
    the background (all other samples). To account for multiple hypothesis 
    testing, P-values are corrected using the Benjamini-Hochberg (FDR) procedure.

    The analysis helps identify "functional markers" — biological functions 
    that significantly characterize a specific taxonomic or environmental group.

    Args:
        matrix_bin (pd.DataFrame): Binary presence/absence matrix (rows: genomes, columns: features).
        metadata_df (pd.DataFrame): Metadata used for defining the groups.
        grouping_column (str): The column in metadata_df used to categorize samples.
        target_group (str): The specific group to be analyzed for enrichment.
        alpha (float, optional): Significance threshold for the False Discovery Rate (FDR). 
                                Defaults to 0.05.

    Returns:
        pd.DataFrame: A DataFrame containing significant results (FDR < alpha), 
                      sorted by significance. Columns include P-value, FDR, 
                      group frequencies, Odds Ratio, and Enrichment Score.
    """
    target_indices = metadata_df[metadata_df[grouping_column] == target_group].index
    background_indices = metadata_df[metadata_df[grouping_column] != target_group].index
    
    n_target = len(target_indices)
    n_bg = len(background_indices)
    results = []
    
    for feature in matrix_bin.columns:
        present_target = matrix_bin.loc[target_indices, feature].sum()
        absent_target = n_target - present_target
        present_bg = matrix_bin.loc[background_indices, feature].sum()
        absent_bg = n_bg - present_bg
        
        table = [[present_target, absent_target], [present_bg, absent_bg]]
        odds_ratio, p_val = fisher_exact(table, alternative='greater')
        
        freq_target = present_target / n_target
        freq_bg = present_bg / n_bg
        
        if present_target > 0:
            results.append({
                'Feature': feature,
                'P-value': p_val,
                'In_Group': f"{present_target}/{n_target} ({freq_target:.1%})",
                'Background': f"{present_bg}/{n_bg} ({freq_bg:.1%})",
                'Odds_Ratio': round(odds_ratio, 2), 
                'Enrichment_Score': round(freq_target - freq_bg, 2)
            })

    if not results:
        return pd.DataFrame()

    enrich_df = pd.DataFrame(results)
    enrich_df['FDR'] = multipletests(enrich_df['P-value'], method='fdr_bh')[1]
    
    significant = enrich_df[enrich_df['FDR'] < alpha].sort_values(by='FDR')
    
    significant['P-value'] = significant['P-value'].apply(lambda x: '{:.4e}'.format(x))
    significant['FDR'] = significant['FDR'].apply(lambda x: '{:.4e}'.format(x))
    
    return significant

def run_permanova_logic(matrix_bin, metadata_df, grouping_column, metric='jaccard', permutations=999):
    """
    Performs Permutational Multivariate Analysis of Variance (PERMANOVA).
    
    PERMANOVA is a non-parametric statistical test used to determine whether 
    the functional differences between predefined groups (e.g., taxonomic ranks) 
    are statistically significant. Unlike traditional ANOVA, it operates on 
    dissimilarity matrices and uses permutations to calculate P-values, making 
    it ideal for binary microbial data where normal distribution cannot be assumed.

    The process involves:
    1. Calculating a distance matrix (Jaccard or Dice) from the binary matrix.
    2. Partitioning the distance matrix based on the grouping factor.
    3. Performing permutations to assess if the between-group variation is 
       significantly larger than within-group variation.

    Args:
        matrix_bin (pd.DataFrame): Binary presence/absence matrix (rows: genomes, columns: features).
        metadata_df (pd.DataFrame): Metadata containing the grouping factors.
        grouping_column (str): The column in metadata_df to be tested (the independent variable).
        metric (str, optional): The distance metric to use ('jaccard' or 'dice'). 
                                Defaults to 'jaccard'.
        permutations (int, optional): Number of random permutations for the test. 
                                      Defaults to 999.

    Returns:
        skbio.stats.distance.permanova_results: A series-like object containing 
                                                the pseudo-F statistic and the P-value.
    """
    # 1. Výpočet matice vzdáleností
    data_float = matrix_bin.values.astype(float)
    dist_vec = pdist(data_float, metric=metric)
    dist_matrix = squareform(dist_vec)
    
    dm = DistanceMatrix(dist_matrix, ids=matrix_bin.index)
    
    # 2. Spuštění PERMANOVA přes skbio
    groups = metadata_df[grouping_column]
    results = permanova(dm, groups, permutations=permutations)
    
    return results  