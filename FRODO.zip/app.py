import sys

def check_dependencies():
    required = {
        'streamlit': 'streamlit',
        'pandas': 'pandas',
        'numpy': 'numpy',
        'plotly': 'plotly',
        'scipy': 'scipy',
        'sklearn': 'scikit-learn',
        'skbio': 'scikit-bio',
        'statsmodels': 'statsmodels'
    }
    
    missing = []
    for module, package in required.items():
        try:
            __import__(module)
        except ImportError:
            missing.append(package)
    
    if missing:
        import streamlit as st
        st.error("### 🛑 Missing Dependencies Detected")
        st.write("The following libraries are not installed. Please install them using the command below:")
        st.code(f"pip install {' '.join(missing)}")
        st.stop()

check_dependencies()

import streamlit as st
import pandas as pd
import time
import zipfile
import io
import os
from processors import create_universal_matrix
from analysis import run_pca_plotly, run_pcoa_plotly, run_cca_plotly, run_cap_plotly, run_tsne_plotly, run_clustering_logic, get_clustering_metrics, run_enrichment_logic, run_permanova_logic

# --- PAGE CONFIG ---
st.set_page_config(page_title="FRODO", layout="wide")

# --- CUSTOM CSS FOR TERMINAL LOG ---
st.markdown("""
    <style>
    .terminal-log {
        background-color: #1e1e1e;
        color: #00ff00;
        padding: 10px;
        border-radius: 5px;
        font-family: 'Courier New', Courier, monospace;
        height: 200px;
        overflow-y: auto;
    }
    </style>
""", unsafe_allow_html=True)

# --- SESSION STATE FOR LOGGING ---
if 'logs' not in st.session_state:
    st.session_state.logs = []

def add_log(message):
    timestamp = time.strftime("%H:%M:%S")
    st.session_state.logs.append(f"[{timestamp}] {message}")

# --- SIDEBAR ---
st.sidebar.title("🛠 Data Hub")

download_placeholder = st.sidebar.empty()

st.sidebar.divider()

st.sidebar.subheader("1. Upload Data")
data_file = st.sidebar.file_uploader("Upload Functional Annotation (TSV/TBL)", type=['tsv', 'tbl'])
tax_file = st.sidebar.file_uploader("Upload Taxonomy Data (TSV)", type=['tsv'])

st.sidebar.divider()

# Sample Download Section
st.sidebar.subheader("2. Reference Templates")
st.sidebar.info("Download sample files to see required format.")

SAMPLE_FUNC_PATH = "dataset_ko.tsv"
SAMPLE_TAX_PATH = "gcf_order.tsv"

# Functional Data Download Button
if os.path.exists(SAMPLE_FUNC_PATH):
    with open(SAMPLE_FUNC_PATH, "rb") as f:
        st.sidebar.download_button(
            label="📥 Download Functional Annotation Sample",
            data=f,
            file_name="example_functional_annotations.tsv",
            mime="text/tab-separated-values",
            help="Download an example KO dataset to see the required structure."
        )

# Taxonomy Download Button
if os.path.exists(SAMPLE_TAX_PATH):
    with open(SAMPLE_TAX_PATH, "rb") as f:
        st.sidebar.download_button(
            label="📥 Download Taxonomy Sample",
            data=f,
            file_name="example_taxonomy.tsv",
            mime="text/tab-separated-values",
            help="Download an example taxonomy file with GCF IDs."
        )

st.sidebar.subheader("3. Process Log")
log_placeholder = st.sidebar.empty()

# --- MAIN AREA ---
st.title("FRODO: Functional Relationships and Ordination Data Observer")
st.markdown("""
One Tool to analyze them all, One Tool to find them...
            
This tool allows you to analyze functional annotations 
across multiple bacterial genomes and link them with taxonomy.
""")

if not data_file or not tax_file:
    st.markdown("""
    ### Welcome to FRODO! 
    To start your analysis, please upload your data in the **Data Hub** on the left.
    
    #### 📂 Required File Formats:
    """)
    
    col_desc1, col_desc2 = st.columns(2)
    
    with col_desc1:
        st.info("""
        **1. Functional Annotation File (.tsv, .tbl)**
                
        This file contains the mapping of organisms to their functions. 
        FRODO accepts two formats:

        - **Universal Tabular Format:** A tab-separated file with these specific headers:
            - **`ID`**: Unique identifier of the organism (e.g., Strain Name, GCF ID, Sample ID).
            - **`Functional Annotation`**: The functional label (e.g., KO number, EC number).
        - **HMMER Output:** Standard output from HMMER. FRODO will automatically extract the IDs and Pfams.
        """)
         
    with col_desc2:
        st.info("""
        **2. Taxonomy Metadata (.tsv)**
                
        A tab-separated file that provides context for your IDs:
        - Must contain an **`ID`** column that matches the Functional file exactly (e.g. the name of annotated protein sequence file).
        - Any other column can be used for coloring and enrichment.
        """)
        
    st.warning("👈 Please use the sidebar to upload your files.")

else:
    # --- STEP 1: PROCESSING ---
    add_log("Files uploaded. Starting preprocessing...")

    matrix_bin, metadata_df = create_universal_matrix(data_file, tax_file)
    add_log(f"Matrix created: {matrix_bin.shape[0]} genomes x {matrix_bin.shape[1]} features.")

    if matrix_bin is not None:
        @st.cache_data
        def convert_df_to_zip(df):
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "x", zipfile.ZIP_DEFLATED) as zf:
                zf.writestr("binary_matrix.tsv", df.to_csv(sep='\t'))
            return buf.getvalue()

        zip_data = convert_df_to_zip(matrix_bin)
        
        download_placeholder.download_button(
            label="📥 Download Binary Matrix (ZIP)",
            data=zip_data,
            file_name='enzyme_matrix.zip',
            mime='application/zip',
            use_container_width=True,
            key="main_download_btn"
        )

    # --- TABS FOR ANALYSIS ---
    tab_ord, tab_clust, tab_enrich, tab_stat = st.tabs([
        "📊 Dimensionality Reduction & Ordination Analysis", 
        "🧮 Clustering Analysis", 
        "🧪 Enrichment Analysis",
        "📈 Statistical Testing"
    ])

    with tab_ord:
        st.header("Dimensionality Reduction & Ordination Analysis")
        
        col_settings, col_plot = st.columns([1, 3])
        
        with col_settings:
            method = st.selectbox("**Choose Method**:", ["PCA", "PCoA", "CCA", "CAP", "t-SNE"])
            
            if method == "PCA":
                with st.expander("🔍 About PCA method"):
                    st.write("""
                    **Principal Component Analysis** highlights clusters and gradients by capturing maximum variance in functional data. 
                    Distances represent **Euclidean distances**: genomes close to each other share similar 
                    enzymatic repertoires, while those far apart have distinct metabolic capabilities.
                    """)
            elif method == "PCoA":
                with st.expander("🔍 About PCoA method"):
                    st.write("""
                    **Principal Coordinates Analysis** is a flexible ordination method ideal for binary data. PCoA handles the 
                    **double zero problem** by ignoring shared absences of enzymes. By focusing on shared 
                    functional presence rather than what is missing, it provides a more biologically 
                    meaningful visualization of metabolic relatedness.
                    """)
                metric = st.selectbox("**Distance Metric**:", ["jaccard", "dice"])
                if metric == "jaccard":
                    st.info("**Jaccard**: A strict metric that measures dissimilarity by calculating the " \
                    "proportion of shared enzymes relative to the total number of features present in either genome, " \
                    "giving equal weight to all shared metabolic capabilities.")
                elif metric == "dice":
                    st.info("**Dice**: Similar to Jaccard but applies double weight to shared enzymes, more effectively " \
                    "highlighting core metabolic similarities between genomes that may otherwise differ in their accessory gene content.")
            elif method == "CCA": 
                with st.expander("🔍 About CCA method"):
                    st.write("""
                    **Canonical Correspondence Analysis** is a constrained ordination method that explicitly tests how much of the functional 
                    variation is explained by a specific factor, such as taxonomy. CCA treats your taxonomic groups 
                    as "environmental variables", allowing you to visualize only the differences in enzymatic profiles that are directly
                    related to the chosen taxonomic level.
                    """)
            elif method == "CAP":
                with st.expander("🔍 About CAP method"):
                    st.write("""
                    **Canonical Analysis of Principal Coordinates** is a constrained ordination method that combines the flexibility of non-Euclidean 
                    metrics (like Jaccard) with the ability to test specific hypotheses. It performs a redundancy analysis on PCoA coordinates, 
                    allowing you to visualize functional variation that is strictly explained by your taxonomic grouping while ignoring the **double zero problem.**
                    """)
                metric = st.selectbox("**Distance Metric**:", ["jaccard", "dice"])
                if metric == "jaccard":
                    st.info("**Jaccard**: A strict metric that measures dissimilarity by calculating the " \
                    "proportion of shared enzymes relative to the total number of features present in either genome, " \
                    "giving equal weight to all shared metabolic capabilities.")
                elif metric == "dice":
                    st.info("**Dice**: Similar to Jaccard but applies double weight to shared enzymes, more effectively " \
                    "highlighting core metabolic similarities between genomes that may otherwise differ in their accessory gene content.")
            elif method == "t-SNE":
                with st.expander("🔍 About t-SNE method"):
                    st.write("""
                    **t-distributed Stochastic Neighbor Embedding** is a non-linear dimensionality reduction technique that excels at preserving 
                    local structure. It ensures that genomes with highly similar enzymatic repertoires are 
                    placed in close proximity, revealing detailed functional neighborhoods and specialized clusters that might be obscured in 
                    global projections.
                    """)
                perp = st.number_input("**Select Perplexity**:", value=30)
                st.info("The **Perplexity** parameter determines the balance between local and global structures. " \
                "Lower Perplexity focuses on fine-scale, local relationships. It is ideal for identifying small, specialized functional "
                "clusters and variability within broad groups. " \
                "Higher Perplexity captures more global patterns, providing a more stable view of the overall functional " \
                "landscape and major taxonomic differences.")

            available_cols = [c for c in metadata_df.columns if c not in ["ID", "ID_clean"]]
            group_col = st.selectbox("**Group by**:", available_cols)
            run_btn = st.button("🚀 Run Analysis")

        with col_plot:
            if run_btn:
                with st.spinner("Processing..."):
                    if method == "PCA":
                        add_log(f"Running PCA...")
                        fig, df_result = run_pca_plotly(matrix_bin, metadata_df, group_col)
                        st.plotly_chart(fig, width='stretch')
                    elif method == "PCoA":
                        add_log(f"Running PCoA...")
                        fig, df_result = run_pcoa_plotly(matrix_bin, metadata_df, group_col, metric=metric)
                        st.plotly_chart(fig, width='stretch')
                    elif method == "CCA":
                        add_log(f"Running CCA...")
                        fig, df_result = run_cca_plotly(matrix_bin, metadata_df, group_col)
                        st.plotly_chart(fig, width='stretch')
                    elif method == "CAP":
                        add_log(f"Running CAP...")
                        fig, df_result = run_cap_plotly(matrix_bin, metadata_df, group_col, metric=metric)
                        st.plotly_chart(fig, width='stretch')
                    else:
                        with st.spinner("Computing t-SNE... this may take a moment."):
                            fig, df_result = run_tsne_plotly(matrix_bin, metadata_df, group_col, perplexity=perp)
                            st.plotly_chart(fig, width='stretch')
                            
                st.session_state['last_ord_df'] = df_result
                st.session_state['last_method'] = method

    with tab_clust:
        if 'last_ord_df' not in st.session_state:
            st.warning("Please run one of the methods from **Dimensionality Reduction & Ordination Analysis** tab first to get the data for clustering.")
        else:
            st.header("K-means Clustering")
            df_to_cluster = st.session_state['last_ord_df']
            method_name = st.session_state['last_method']
            st.info(f"**Current Input:** Results from the last performed **{method_name}** analysis. "
                "Clustering is automatically applied to the coordinates generated in the Ordination tab.")

            with st.expander("🔍 About K-Means Clustering"):
                st.write("""
                **K-means clustering** partitions genomes into k groups by minimizing the distance between points and the center of their assigned cluster. 
                When performed on ordination coordinates, it helps identify functional groups that are objectively similar regardless of their taxonomic labels.
                """)
            
            available_axes = [c for c in st.session_state.last_ord_df.columns if any(x in c for x in ['PC', 'Axis', 'CCA', 'CAP', 't-SNE'])]
            
            col1, col2 = st.columns([1, 2])
            with col1:
                x_ax = st.selectbox("**X Axis for clustering**:", available_axes, index=0)
                y_ax = st.selectbox("**Y Axis for clustering**:", available_axes, index=1 if len(available_axes)>1 else 0)
                k_val = st.number_input("**Number of clusters (k):**", value=5)
                tax_col = st.selectbox("**Compare with**:", available_cols)
                run_c = st.button("🚀 Run Clustering")
                
            with col2:
                if run_c:
                    fig_clust, df_clustered = run_clustering_logic(st.session_state.last_ord_df, x_ax, y_ax, tax_col, k_val)
                    st.plotly_chart(fig_clust, width='stretch')
                    
                    metrics = get_clustering_metrics(df_clustered, tax_col)
                    
                    st.subheader("Clustering Metrics")
                    m_col1, m_col2, m_col3, m_col4 = st.columns(4)
                    m_col1.metric("Purity", f"{metrics['Purity']:.2f}")
                    m_col2.metric("V-Measure", f"{metrics['V-measure']:.2f}")
                    m_col3.metric("Homogeneity", f"{metrics['Homogeneity']:.2f}")
                    m_col4.metric("Completeness", f"{metrics['Completeness']:.2f}")

                    st.divider()
                    with st.expander("Interpretation of Clustering Metrics"):
                        st.markdown(f"""
                        These metrics evaluate the agreement between the **K-means clusters** (mathematical similarity) 
                        and your **Taxonomy** (biological classification at the *{tax_col}* level). 
                        All scores range from **0.0 to 1.0** (higher is better).

                        * **Purity**: Measures the average proportion of the majority taxon within each cluster. A score of 1.0 means every cluster consists of only one taxonomic group.
                        * **Homogeneity**: High if each cluster contains only members of a single taxonomic group. It tells you how "clean" your clusters are.
                        * **Completeness**: High if all members of a given taxonomic group are assigned to the same cluster. It tells you if a specific taxon was split into multiple clusters.
                        * **V-Measure**: The harmonic mean of Homogeneity and Completeness. It provides an overall score of how well the ordination axes separate your taxonomic groups.
                        """)

                    st.subheader("📋 Cluster Assignments")
    
                    report_df = df_clustered[['ID', tax_col, 'Cluster']].copy()
                    report_df = report_df.sort_values(['Cluster', 'ID'])

                    with st.expander("View full list of IDs and their assigned clusters"):
                        st.dataframe(report_df, use_container_width=True, hide_index=True)
                        
                        csv = report_df.to_csv(index=False).encode('utf-8')
                        st.download_button(
                            label="📥 Download assignments as CSV",
                            data=csv,
                            file_name=f"clustering_results_k{k_val}.csv",
                            mime="text/csv",
                        )

    with tab_enrich:
        st.header("Functional Enrichment")
        st.markdown("Identify which functions are significantly overrepresented in a specific group.")
        
        target_group = st.selectbox("Select Target Group for Enrichment:", metadata_df[group_col].unique())

        group_size = len(metadata_df[metadata_df[group_col] == target_group])
    
        if group_size < 2:
            st.error(f"⚠️ **Group too small!** The selected group '{target_group}' contains only {group_size} genome(s).")
            st.info("Fisher's Exact Test requires at least 2 samples in the target group to calculate statistical significance after FDR correction.")
        else:
            if st.button("Run Fisher's Test"):
                add_log(f"Running Enrichment for {target_group}...")
                enrich_results = run_enrichment_logic(matrix_bin, metadata_df, group_col, target_group)
                
                st.write(f"### Significant functions in {target_group}")

                with st.expander("📖 How to interpret the results?"):
                    st.markdown("""
                    - **Feature**: The name/ID of the enzyme or functional category.
                    - **P-value**: Raw probability from Fisher's Exact Test. Lower is better.
                    - **In_Group**: Frequency of the feature within your selected group.
                    - **Background**: Frequency of the feature in all other samples.
                    - **Odds Ratio**: Measures the strength of association. 
                        - *Example: 2.5 means the enzyme is 2.5x more likely to be in your group than in the background.*
                        - If the **Odds Ratio** shows 'inf', it means the feature was **never found in the background samples** (0 hits). 
                        From a biological perspective, these are your **Unique Functional Markers** — features that are strictly specific to your target group.
                    - **Enrichment Score**: Simple difference in frequency (Group % - Background %). 
                        - *1.0 means it's ONLY in your group; 0.0 means no difference.*
                    - **FDR (False Discovery Rate)**: The most important value. It is the P-value corrected for multiple testing. 
                        - *Standard threshold for significance is **FDR < 0.05**.*
                    """)

                st.dataframe(enrich_results)
                
                # Download button for results
                csv = enrich_results.to_csv(sep='\t', index=False).encode('utf-8')
                st.download_button("Download Results in TSV format)", csv, f"enrichment_{target_group}.tsv", "text/tab-separated-values")
                add_log("Enrichment analysis finished.")

    with tab_stat:
        st.header("PERMANOVA")
        st.write("""
        PERMANOVA (Permutational Multivariate Analysis of Variance) is a non-parametric statistical test used to determine whether the functional 
        differences between predefined groups (e.g., genera or orders) are significant. It operates on a distance matrix and uses permutations to calculate 
        a p-value, making it ideal for binary enzymatic data where normal distribution cannot be assumed.
        """)
        
        col1, col2 = st.columns([1, 2])

        help_metric = (
            "Choose how to calculate distance between genomes. "
            "Jaccard measures the proportion of shared enzymes. "
            "Dice gives double weight to shared enzymes, emphasizing core similarities."
        )

        help_group = (
            "The taxonomic level or category you want to test. "
            "PERMANOVA will check if functional profiles differ significantly between these groups."
        )

        help_perms = (
            "Number of random shuffles to calculate significance. "
            "999 is standard for publication; higher numbers give more precise p-values but take longer."
        )
        
        with col1:
            stat_metric = st.selectbox(
                "**Distance Metric**:", 
                ["jaccard", "dice"], 
                key="stat_met",
                help=help_metric
            )

            stat_group = st.selectbox(
                "**Factor to test**:", 
                available_cols, 
                key="stat_grp",
                help=help_group
            )

            perms = st.number_input(
                "**Number of permutations**:", 
                min_value=99, 
                max_value=9999, 
                value=999, 
                step=100,
                help=help_perms
            )

            run_stat = st.button("🚀 Run PERMANOVA Test")

        with col2:
            if run_stat:
                with st.spinner("Calculating permutations..."):
                    results = run_permanova_logic(matrix_bin, metadata_df, stat_group, metric=stat_metric, permutations=perms)
                    
                    # Zobrazení výsledků v hezkém formátu
                    st.subheader("Test Results")
                    
                    # Vytvoření přehledné tabulky
                    res_df = pd.DataFrame({
                        "Parameter": ["Test Statistic (F)", "P-value", "Permutations"],
                        "Value": [f"{results['test statistic']:.4f}", f"{results['p-value']:.4f}", perms]
                    })
                    st.table(res_df)
                    
                    # Interpretace
                    p_val = results['p-value']
                    if p_val < 0.05:
                        st.success(f"✅ **Significant result!** (p = {p_val:.4f}). The functional profiles of the selected groups are statistically distinct.")
                    else:
                        st.warning(f"⚠️ **Not significant.** (p = {p_val:.4f}). No systematic functional differences were found between the groups.")

# Refresh terminal log in sidebar
log_content = "<div class='terminal-log'>" + "<br>".join(st.session_state.logs[::-1]) + "</div>"
log_placeholder.markdown(log_content, unsafe_allow_html=True)